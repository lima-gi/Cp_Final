package br.com.fiap.bean;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class IndexBean {

	public void execute() {
		System.out.println("Executando comando...");
	}
	
}
